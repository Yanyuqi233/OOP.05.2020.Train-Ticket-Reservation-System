/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

/**
 *
 * @author Administrator
 */
public class message {
    private String M_number;
    private String M_message;
            
public String GetM_number(){
        return M_number;
    }
public void setM_number(String M_number)
    {
        this.M_number=M_number;
    }
public String GetM_message(){
        return M_message;
    }
public void setM_message(String M_message)
    {
        this.M_message=M_message;
    }
}
